from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api import auth, reports, scans
from .core.config import settings
from .database import init_db

# Создаём приложение
app = FastAPI(
    title="Lung Scan Backend API",
    description="Backend API for Chest CT Scan Analysis",
    version="1.0.0",
)

# CORS настройки (разрешаем фронтенд)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Подключаем роутеры
app.include_router(auth.router)
app.include_router(scans.router)
app.include_router(reports.router)


@app.on_event("startup")
async def startup_event():
    """Инициализация при старте"""
    print("Starting Lung Scan Backend...")
    print(f"Database: {settings.DATABASE_URL}")
    print(f"CORS enabled for: {settings.cors_origins_list}")

    # Инициализируем БД (создаём таблицы)
    init_db()
    print("Database initialized")


@app.get("/")
async def root():
    """Корневой endpoint"""
    return {"message": "Lung Scan Backend API", "version": "1.0.0", "status": "running"}


@app.get("/health")
async def health_check():
    """Проверка здоровья сервиса"""
    return {"status": "healthy"}
