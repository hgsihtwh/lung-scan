from datetime import datetime

from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from .database import Base


class User(Base):
    """Пользователи системы"""

    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Связи
    scans = relationship("Scan", back_populates="owner", cascade="all, delete-orphan")


class Scan(Base):
    """Исследования (загруженные DICOM файлы)"""

    __tablename__ = "scans"

    id = Column(Integer, primary_key=True, index=True)
    file_id = Column(String, unique=True, index=True, nullable=False)  # UUID архива
    file_hash = Column(String, index=True, nullable=True)  # SHA-256 хэш файла
    study_instance_uid = Column(String, index=True, nullable=True)  # Убрали unique
    patient_name = Column(String, nullable=True)
    status = Column(
        String, default="uploaded"
    )  # uploaded, processing, completed, failed
    slice_count = Column(Integer, default=0)  # Количество срезов
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    # Связи
    owner = relationship("User", back_populates="scans")
    report = relationship(
        "Report", back_populates="scan", uselist=False, cascade="all, delete-orphan"
    )
    feedback = relationship(
        "Feedback", back_populates="scan", uselist=False, cascade="all, delete-orphan"
    )


class Report(Base):
    """Результаты анализа"""

    __tablename__ = "reports"

    id = Column(Integer, primary_key=True, index=True)
    scan_id = Column(Integer, ForeignKey("scans.id"), unique=True, nullable=False)
    verdict = Column(String, nullable=False)  # "Normal" / "Pathology"
    probability = Column(Float, nullable=False)  # 0.0 - 1.0
    created_at = Column(DateTime, default=datetime.utcnow)

    # Связи
    scan = relationship("Scan", back_populates="report")


class Feedback(Base):
    """Обратная связь от пользователя"""

    __tablename__ = "feedbacks"

    id = Column(Integer, primary_key=True, index=True)
    scan_id = Column(Integer, ForeignKey("scans.id"), unique=True, nullable=False)
    is_accurate = Column(
        Boolean, nullable=True
    )  # True = accurate, False = inaccurate, None = no feedback
    user_comment = Column(String, nullable=True)  # Комментарий пользователя
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Связи
    scan = relationship("Scan", back_populates="feedback")
