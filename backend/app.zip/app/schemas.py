from datetime import datetime

from pydantic import BaseModel, EmailStr, Field

# --- AUTH SCHEMAS ---


class UserRegister(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=4, max_length=72)


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserResponse(BaseModel):
    id: int
    email: str
    created_at: datetime

    class Config:
        from_attributes = True


# --- SCAN SCHEMAS ---


class ScanResponse(BaseModel):
    id: int
    file_id: str
    patient_name: str | None
    status: str
    slice_count: int
    created_at: datetime
    verdict: str | None = None
    probability: float | None = None

    class Config:
        from_attributes = True


class ScanDetailResponse(ScanResponse):
    """Детальная информация о скане с результатами"""

    verdict: str | None = None
    probability: float | None = None
    has_feedback: bool = False
    is_accurate: bool | None = None
    user_comment: str | None = None

    class Config:
        from_attributes = True


# --- REPORT SCHEMAS ---


class ReportResponse(BaseModel):
    id: int
    scan_id: int
    verdict: str
    probability: float
    created_at: datetime

    class Config:
        from_attributes = True


class AnalysisResult(BaseModel):
    """Результат анализа"""

    status: str  # "completed", "already_analyzed", "processing"
    verdict: str | None = None
    probability: float | None = None


# --- FEEDBACK SCHEMAS ---


class FeedbackCreate(BaseModel):
    is_accurate: bool  # True = accurate, False = inaccurate
    user_comment: str | None = None


class FeedbackResponse(BaseModel):
    id: int
    scan_id: int
    is_accurate: bool | None
    user_comment: str | None
    created_at: datetime

    class Config:
        from_attributes = True


# --- COMMENT SCHEMA ---


class CommentCreate(BaseModel):
    comment: str = Field(..., max_length=5000)


# --- UPLOAD SCHEMAS ---


class UploadResponse(BaseModel):
    status: str
    scan_id: int
    message: str
    slice_count: int
