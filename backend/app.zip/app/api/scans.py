import os
import shutil
import uuid
import zipfile
from collections import defaultdict
from pathlib import Path

import pydicom
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Feedback, Report, Scan, User
from ..schemas import (
    AnalysisResult,
    CommentCreate,
    FeedbackCreate,
    FeedbackResponse,
    ScanDetailResponse,
    ScanResponse,
    UploadResponse,
)
from .deps import get_current_user

router = APIRouter(prefix="/api/scans", tags=["Scans"])

# Директории для данных
UPLOAD_DIR = Path("data/raw")
PROCESSED_DIR = Path("data/processed")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)


def validate_dicom_file(file_path: Path) -> tuple[bool, int, str]:
    """Валидация DICOM файла"""
    try:
        ds = pydicom.dcmread(file_path, stop_before_pixels=True)

        if "PatientName" not in ds:
            return False, 0, ""

        instance_number = int(ds.InstanceNumber) if "InstanceNumber" in ds else 0
        patient_name = str(ds.PatientName)

        return True, instance_number, patient_name
    except Exception:
        return False, 0, ""


@router.post(
    "/upload", response_model=UploadResponse, status_code=status.HTTP_201_CREATED
)
async def upload_dicom(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Загрузка ZIP архива с DICOM файлами"""
    import hashlib

    try:
        # Проверяем что это ZIP
        if not file.filename or not file.filename.endswith(".zip"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Only ZIP archives are supported",
            )

        # Читаем содержимое файла и вычисляем хэш
        file_content = await file.read()
        file_hash = hashlib.sha256(file_content).hexdigest()
        print(f"[DEBUG] File hash: {file_hash}")

        # Проверяем существует ли уже этот файл у пользователя
        existing_scan = (
            db.query(Scan)
            .filter(
                Scan.file_hash == file_hash,
                Scan.user_id == current_user.id,
            )
            .first()
        )

        if existing_scan:
            print(f"[DEBUG] Found existing scan by hash with ID: {existing_scan.id}")
            return UploadResponse(
                status="exists",
                scan_id=existing_scan.id,
                message="This study already exists in your history",
                slice_count=existing_scan.slice_count,
            )

        # Генерируем уникальный ID для хранения
        batch_id = str(uuid.uuid4())
        temp_zip = UPLOAD_DIR / f"{batch_id}.zip"
        extract_dir = PROCESSED_DIR / batch_id

        # Сохраняем ZIP
        try:
            with open(temp_zip, "wb") as buffer:
                buffer.write(file_content)
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error saving file: {e!s}",
            )

        # Распаковываем
        try:
            with zipfile.ZipFile(temp_zip, "r") as z:
                z.extractall(extract_dir)
        except Exception as e:
            temp_zip.unlink(missing_ok=True)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid ZIP archive: {e!s}",
            )

        # Собираем и валидируем DICOM файлы + извлекаем StudyInstanceUID
        patient_groups = defaultdict(lambda: {"indices": set(), "paths": []})
        study_instance_uid = None

        for root, _, files in os.walk(extract_dir):
            for f in files:
                if f.startswith("."):
                    continue

                file_path = Path(root) / f

                try:
                    ds = pydicom.dcmread(file_path, stop_before_pixels=True)

                    # Проверяем обязательные поля
                    if "PatientName" not in ds:
                        continue

                    patient_name = str(ds.PatientName)

                    # Извлекаем StudyInstanceUID (один раз)
                    if study_instance_uid is None and "StudyInstanceUID" in ds:
                        study_instance_uid = str(ds.StudyInstanceUID)
                        print(
                            f"[DEBUG] Extracted StudyInstanceUID: {study_instance_uid}"
                        )

                    # Извлекаем InstanceNumber
                    instance_number = (
                        int(ds.InstanceNumber) if "InstanceNumber" in ds else 0
                    )

                    patient_groups[patient_name]["indices"].add(instance_number)
                    patient_groups[patient_name]["paths"].append(file_path)

                except Exception as e:
                    print(f"[DEBUG] Failed to read DICOM file {f}: {e}")
                    shutil.rmtree(extract_dir, ignore_errors=True)
                    temp_zip.unlink(missing_ok=True)
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Invalid DICOM file found: {f}",
                    )

        # Проверяем что есть файлы
        if not patient_groups:
            shutil.rmtree(extract_dir, ignore_errors=True)
            temp_zip.unlink(missing_ok=True)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No valid DICOM files found in archive",
            )

        # Берём первого пациента
        patient_name = list(patient_groups.keys())[0]
        unique_slice_count = len(patient_groups[patient_name]["indices"])

        print(f"[DEBUG] Patient: {patient_name}")
        print(f"[DEBUG] Unique slices: {unique_slice_count}")

        # Создаём новую запись в БД
        new_scan = Scan(
            file_id=batch_id,
            file_hash=file_hash,
            study_instance_uid=study_instance_uid,
            patient_name=patient_name,
            status="completed",
            slice_count=unique_slice_count,
            user_id=current_user.id,
        )

        db.add(new_scan)
        db.commit()
        db.refresh(new_scan)

        print(f"[DEBUG] Created new scan with ID: {new_scan.id}")

        return UploadResponse(
            status="success",
            scan_id=new_scan.id,
            message=f"Successfully uploaded {unique_slice_count} slices",
            slice_count=unique_slice_count,
        )

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Upload failed: {e!s}",
        )


@router.get("/", response_model=list[ScanResponse])
async def get_scans(
    db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    """Получить все сканы пользователя (история)"""
    try:
        scans = (
            db.query(Scan)
            .filter(Scan.user_id == current_user.id)
            .order_by(Scan.created_at.desc())
            .all()
        )

        # Добавляем verdict и probability из связанного Report
        result = []
        for scan in scans:
            scan_dict = {
                "id": scan.id,
                "file_id": scan.file_id,
                "patient_name": scan.patient_name,
                "status": scan.status,
                "slice_count": scan.slice_count,
                "created_at": scan.created_at,
                "verdict": scan.report.verdict if scan.report else None,
                "probability": scan.report.probability if scan.report else None,
            }
            result.append(scan_dict)

        return result
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving scans: {e!s}",
        )


@router.get("/{scan_id}", response_model=ScanDetailResponse)
async def get_scan(
    scan_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Получить детальную информацию о скане"""
    try:
        scan = (
            db.query(Scan)
            .filter(Scan.id == scan_id, Scan.user_id == current_user.id)
            .first()
        )

        if not scan:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Scan not found"
            )

        # Формируем ответ
        response = ScanDetailResponse(
            id=scan.id,
            file_id=scan.file_id,
            patient_name=scan.patient_name,
            status=scan.status,
            slice_count=scan.slice_count,
            created_at=scan.created_at,
            verdict=scan.report.verdict if scan.report else None,
            probability=scan.report.probability if scan.report else None,
            has_feedback=scan.feedback is not None,
            is_accurate=scan.feedback.is_accurate
            if scan.feedback
            else None,  # ← ДОБАВЬ ЭТУ СТРОКУ
            user_comment=scan.feedback.user_comment if scan.feedback else None,
        )

        return response

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving scan: {e!s}",
        )


@router.get("/{scan_id}/slices", response_model=list[int])
async def get_slice_numbers(
    scan_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Получить список всех номеров срезов"""
    try:
        scan = (
            db.query(Scan)
            .filter(Scan.id == scan_id, Scan.user_id == current_user.id)
            .first()
        )

        if not scan:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Scan not found"
            )

        scan_dir = PROCESSED_DIR / scan.file_id

        if not scan_dir.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Scan files not found on server",
            )

        slice_numbers = []

        for root, _, files in os.walk(scan_dir):
            for f in files:
                if f.startswith("."):
                    continue

                file_path = Path(root) / f
                try:
                    ds = pydicom.dcmread(file_path, stop_before_pixels=True)
                    if "InstanceNumber" in ds:
                        slice_numbers.append(int(ds.InstanceNumber))
                except Exception:
                    continue

        if not slice_numbers:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="No slices found"
            )

        return sorted(slice_numbers)

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving slices: {e!s}",
        )


@router.get("/{scan_id}/slices/{slice_number}")
async def get_slice(
    scan_id: int,
    slice_number: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Получить конкретный срез DICOM"""
    try:
        scan = (
            db.query(Scan)
            .filter(Scan.id == scan_id, Scan.user_id == current_user.id)
            .first()
        )

        if not scan:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Scan not found"
            )

        scan_dir = PROCESSED_DIR / scan.file_id

        if not scan_dir.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Scan files not found on server",
            )

        # Находим файл с нужным номером среза
        for root, _, files in os.walk(scan_dir):
            for f in files:
                if f.startswith("."):
                    continue

                file_path = Path(root) / f
                try:
                    ds = pydicom.dcmread(file_path, stop_before_pixels=True)
                    if (
                        "InstanceNumber" in ds
                        and int(ds.InstanceNumber) == slice_number
                    ):
                        return FileResponse(
                            file_path,
                            media_type="application/dicom",
                            filename=f"slice_{slice_number}.dcm",
                        )
                except Exception:
                    continue

        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Slice {slice_number} not found",
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving slice: {e!s}",
        )


@router.post("/{scan_id}/analyze", response_model=AnalysisResult)
async def start_analysis(
    scan_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Запустить AI анализ (можно перезапускать)"""
    import requests

    from ..core.config import settings

    try:
        scan = (
            db.query(Scan)
            .filter(Scan.id == scan_id, Scan.user_id == current_user.id)
            .first()
        )

        if not scan:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Scan not found"
            )

        # Если уже есть отчёт - удаляем старый (перезапуск анализа)
        if scan.report:
            db.delete(scan.report)
            db.commit()

        # Находим ZIP файл исследования
        zip_path = UPLOAD_DIR / f"{scan.file_id}.zip"

        if not zip_path.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Study archive not found"
            )

        # Отправляем ZIP на модель
        try:
            with open(zip_path, "rb") as f:
                response = requests.post(
                    settings.MODEL_API_URL,
                    files={"file": (f"{scan.file_id}.zip", f, "application/zip")},
                    timeout=300,  # 5 минут на анализ
                )

            if response.status_code != 200:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Model API error: {response.text}",
                )

            result = response.json()
            print(f"[DEBUG] Model response: {result}")

            # Парсим ответ модели
            classification = result.get("prediction", "").lower()
            probability = float(result.get("probability", 0.0))

            # Преобразуем в наш формат
            if classification == "normal":
                verdict = "Normal"
                confidence = 1.0 - probability
            else:
                verdict = "Pathology"
                confidence = probability

        except requests.exceptions.ConnectionError:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Model service is not available. Please try again later.",
            )
        except requests.exceptions.Timeout:
            raise HTTPException(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                detail="Model analysis timed out. Please try again.",
            )

        # Создаём новый отчёт
        report = Report(
            scan_id=scan.id, verdict=verdict, probability=round(confidence, 4)
        )
        db.add(report)

        # Обновляем статус скана
        scan.status = "completed"

        db.commit()
        db.refresh(report)

        return AnalysisResult(
            status="completed", verdict=report.verdict, probability=report.probability
        )

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Analysis failed: {e!s}",
        )


@router.post("/{scan_id}/comments")
async def save_comments(
    scan_id: int,
    data: CommentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Сохранить комментарий пользователя"""
    try:
        scan = (
            db.query(Scan)
            .filter(Scan.id == scan_id, Scan.user_id == current_user.id)
            .first()
        )

        if not scan:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Scan not found"
            )

        # Обновляем или создаём feedback
        feedback = db.query(Feedback).filter(Feedback.scan_id == scan_id).first()

        if feedback:
            feedback.user_comment = data.comment
        else:
            feedback = Feedback(scan_id=scan_id, user_comment=data.comment)
            db.add(feedback)

        db.commit()

        return {"status": "success", "message": "Comment saved"}

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error saving comment: {e!s}",
        )


@router.post("/{scan_id}/feedback", response_model=FeedbackResponse)
async def save_feedback(
    scan_id: int,
    feedback_data: FeedbackCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Сохранить фидбек (accurate/inaccurate)"""
    try:
        scan = (
            db.query(Scan)
            .filter(Scan.id == scan_id, Scan.user_id == current_user.id)
            .first()
        )

        if not scan:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Scan not found"
            )

        # Проверяем что есть отчёт
        if not scan.report:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot provide feedback without analysis results",
            )

        # Обновляем или создаём feedback
        feedback = db.query(Feedback).filter(Feedback.scan_id == scan_id).first()

        if feedback:
            feedback.is_accurate = feedback_data.is_accurate
            if feedback_data.user_comment:
                feedback.user_comment = feedback_data.user_comment
        else:
            feedback = Feedback(
                scan_id=scan_id,
                is_accurate=feedback_data.is_accurate,
                user_comment=feedback_data.user_comment,
            )
            db.add(feedback)

        db.commit()
        db.refresh(feedback)

        return feedback

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error saving feedback: {e!s}",
        )


@router.get("/{scan_id}/report")
async def download_scan_report(
    scan_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Скачать Excel отчет для конкретного скана"""
    try:
        scan = (
            db.query(Scan)
            .filter(Scan.id == scan_id, Scan.user_id == current_user.id)
            .first()
        )

        if not scan:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Scan not found"
            )

        # Проверяем что есть результат анализа
        if not scan.report:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Analysis not completed. Please run analysis first.",
            )

        # Получаем фидбек и комментарий
        feedback = db.query(Feedback).filter(Feedback.scan_id == scan_id).first()

        # Считаем УНИКАЛЬНЫЕ срезы (без дубликатов)
        scan_dir = PROCESSED_DIR / scan.file_id
        unique_slices = set()

        if scan_dir.exists():
            for root, _, files in os.walk(scan_dir):
                for f in files:
                    if f.startswith("."):
                        continue
                    file_path = Path(root) / f
                    try:
                        ds = pydicom.dcmread(file_path, stop_before_pixels=True)
                        if "InstanceNumber" in ds:
                            unique_slices.add(int(ds.InstanceNumber))
                    except Exception:
                        continue

        actual_slice_count = len(unique_slices) if unique_slices else scan.slice_count

        # Формируем данные для Excel
        data = {
            "Field": [
                "Study ID",
                "Date",
                "Slices Count",
                "Verdict",
                "Confidence",
                "User Feedback",
                "User Comment",
            ],
            "Value": [
                scan.patient_name or "N/A",
                scan.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                actual_slice_count,
                scan.report.verdict,
                f"{scan.report.probability * 100:.2f}%",
                "Accurate"
                if feedback and feedback.is_accurate
                else "Inaccurate"
                if feedback and feedback.is_accurate is False
                else "Not provided",
                feedback.user_comment
                if feedback and feedback.user_comment
                else "No comment",
            ],
        }

        # Создаём Excel
        import io

        import pandas as pd

        df = pd.DataFrame(data)
        output = io.BytesIO()

        with pd.ExcelWriter(output, engine="openpyxl") as writer:
            df.to_excel(writer, index=False, sheet_name="Scan Report")

        output.seek(0)

        from fastapi.responses import StreamingResponse

        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition": f"attachment; filename=scan_report_{scan.patient_name or scan_id}.xlsx"
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error generating report: {e!s}",
        )
