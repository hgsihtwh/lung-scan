import { apiClient } from './client'

// Регистрация
export const register = async (email, password) => {
  return apiClient('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  })
}

// Вход (OAuth2 требует FormData)
export const login = async (email, password) => {
  const formData = new FormData()
  formData.append('username', email) // OAuth2 использует 'username'
  formData.append('password', password)
  
  return apiClient('/api/auth/login', {
    method: 'POST',
    body: formData
  })
}