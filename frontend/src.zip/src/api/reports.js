import { downloadFile } from './client'
import { saveComment } from './scans'

// Скачать Excel отчет для скана
export const downloadScanReport = async (scanId, comment, token) => {
  try {
    // Сначала сохраняем комментарий если есть
    if (comment && comment.trim()) {
      await saveComment(scanId, comment, token)
    }
    
    // Затем скачиваем отчет
    return downloadFile(
      `/api/scans/${scanId}/report`,
      `scan_report_${scanId}.xlsx`,
      token
    )
  } catch (error) {
    return { success: false, error: error.message }
  }
}

// Скачать PDF отчет
export const downloadPdfReport = async (scanId, token) => {
  return downloadFile(
    `/api/reports/pdf/${scanId}`,
    `Report_Scan_${scanId}.pdf`,
    token
  )
}

// Экспорт реестра всех исследований
export const downloadRegistry = async (token) => {
  return downloadFile(
    '/api/reports/registry',
    'scans_registry.xlsx',
    token
  )
}