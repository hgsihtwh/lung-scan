// Auth
export { register, login } from './auth'

// Scans
export {
  uploadDicom,
  getScans,
  getScanDetails,
  getSliceNumbers,
  getSlice,
  analyzeScans,
  saveFeedback,
  saveComment
} from './scans'

// Reports
export {
  downloadScanReport,
  downloadPdfReport,
  downloadRegistry
} from './reports'
