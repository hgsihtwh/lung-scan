import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Header from "./components/Header"
import Hero from "./components/Hero"
import About from "./components/About"
import FileUpload from "./components/FileUpload"
import DicomViewer from "./components/DicomViewer"
import Footer from "./components/Footer"
import Auth from "./components/Auth"
import ProfilePage from "./components/ProfilePage"
import lungAscii from "./assets/blue-lung-ascii.svg"
import useAppStore from "./store/useAppStore"

// Защищённый роут
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated } = useAppStore()
  
  if (!isAuthenticated) {
    return <Navigate to="/auth" replace />
  }
  
  return children
}

// Главная страница
function MainPage() {
  const { isAuthenticated, currentStep, currentScanId } = useAppStore()

  // Если есть сохраненный scanId и авторизован - показываем viewer
  const shouldShowViewer = currentStep === "viewer" || (isAuthenticated && currentScanId)

  return (
    <div className="min-h-screen bg-primary-beige relative">
      <img
        src={lungAscii}
        alt=""
        className="absolute -right-10 -top-20 w-[1200px] pointer-events-none select-none z-10"
        style={{ opacity: 0.9 }}
      />

      <div className="relative z-20">
        <Header />
        <Hero />
        <About />
        
        {/* Показываем Upload Study или DicomViewer */}
        {isAuthenticated && (
          shouldShowViewer ? <DicomViewer /> : <FileUpload />
        )}
        
        <Footer />
      </div>
    </div>
  )
}

function App() {
  const { isAuthenticated } = useAppStore()

  return (
    <BrowserRouter>
      <Routes>
        {/* Главная страница */}
        <Route path="/" element={<MainPage />} />
        
        {/* Auth страница */}
        <Route 
          path="/auth" 
          element={isAuthenticated ? <Navigate to="/" replace /> : <Auth />} 
        />

        {/* Profile страница (защищённая) */}
        <Route 
          path="/profile" 
          element={
            <ProtectedRoute>
              <ProfilePage />
            </ProtectedRoute>
          } 
        />

        {/* Редирект */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App