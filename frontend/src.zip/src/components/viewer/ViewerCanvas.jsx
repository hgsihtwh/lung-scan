import { useRef, useEffect, useState } from 'react'
import { getSlice } from '@/api'
import { cornerstone, cornerstoneWADOImageLoader } from '@/utils/cornerstoneSetup'
import ViewerControls from './ViewerControls'

const ViewerCanvas = ({ 
  scanId, 
  currentSlice, 
  token,
  sliceNumbers 
}) => {
  const viewerRef = useRef(null)
  const [isViewerEnabled, setIsViewerEnabled] = useState(false)

  // Инициализация Cornerstone элемента
  useEffect(() => {
    if (viewerRef.current && !isViewerEnabled && sliceNumbers.length > 0) {
      try {
        cornerstone.enable(viewerRef.current)
        setIsViewerEnabled(true)
      } catch (err) {
        console.error('Failed to enable cornerstone:', err)
      }
    }

    return () => {
      if (viewerRef.current && isViewerEnabled) {
        try {
          cornerstone.disable(viewerRef.current)
        } catch (err) {
          console.error('Failed to disable cornerstone:', err)
        }
      }
    }
  }, [sliceNumbers, isViewerEnabled])

  // Загрузка и отображение текущего среза
  useEffect(() => {
    const loadAndDisplaySlice = async () => {
      if (!viewerRef.current || !isViewerEnabled || !currentSlice || !scanId || !token) {
        return
      }

      try {
        // Получаем DICOM файл с бэка
        const result = await getSlice(scanId, currentSlice, token)
        
        if (!result.success) {
          console.error('Failed to load slice:', result.error)
          return
        }

        // Создаём URL для blob
        const blob = result.data
        const arrayBuffer = await blob.arrayBuffer()
        const byteArray = new Uint8Array(arrayBuffer)

        // Создаём imageId для cornerstone
        const imageId = cornerstoneWADOImageLoader.wadouri.fileManager.add(
          new File([byteArray], `slice_${currentSlice}.dcm`)
        )

        // Загружаем и отображаем изображение
        const image = await cornerstone.loadImage(imageId)
        cornerstone.displayImage(viewerRef.current, image)
        
        // Автоматическая настройка яркости/контрастности
        const viewport = cornerstone.getViewport(viewerRef.current)
        viewport.voi.windowWidth = image.windowWidth || 400
        viewport.voi.windowCenter = image.windowCenter || 40
        cornerstone.setViewport(viewerRef.current, viewport)

      } catch (err) {
        console.error('Error displaying slice:', err)
      }
    }

    loadAndDisplaySlice()
  }, [currentSlice, isViewerEnabled, scanId, token])

  // Функции управления изображением
  const handleZoomIn = () => {
    if (!viewerRef.current || !isViewerEnabled) return
    const viewport = cornerstone.getViewport(viewerRef.current)
    viewport.scale += 0.25
    cornerstone.setViewport(viewerRef.current, viewport)
  }

  const handleZoomOut = () => {
    if (!viewerRef.current || !isViewerEnabled) return
    const viewport = cornerstone.getViewport(viewerRef.current)
    viewport.scale = Math.max(0.25, viewport.scale - 0.25)
    cornerstone.setViewport(viewerRef.current, viewport)
  }

  const handleRotate = () => {
    if (!viewerRef.current || !isViewerEnabled) return
    const viewport = cornerstone.getViewport(viewerRef.current)
    viewport.rotation += 90
    cornerstone.setViewport(viewerRef.current, viewport)
  }

  // Включить режим Pan (перетаскивание)
  const handlePan = () => {
    if (!viewerRef.current || !isViewerEnabled) return
    
    let isDragging = false
    let lastX = 0
    let lastY = 0

    const element = viewerRef.current

    const onMouseDown = (e) => {
      isDragging = true
      lastX = e.clientX
      lastY = e.clientY
      e.preventDefault()
      element.style.cursor = 'grabbing'
    }

    const onMouseMove = (e) => {
      if (!isDragging) return

      const deltaX = e.clientX - lastX
      const deltaY = e.clientY - lastY

      lastX = e.clientX
      lastY = e.clientY

      const viewport = cornerstone.getViewport(element)
      viewport.translation.x += deltaX / viewport.scale
      viewport.translation.y += deltaY / viewport.scale
      cornerstone.setViewport(element, viewport)
    }

    const onMouseUp = () => {
      isDragging = false
      element.style.cursor = 'default'
    }

    element.addEventListener('mousedown', onMouseDown)
    element.addEventListener('mousemove', onMouseMove)
    element.addEventListener('mouseup', onMouseUp)
    element.addEventListener('mouseleave', onMouseUp)

    // Очистка после использования (автоотключение через 30 сек)
    setTimeout(() => {
      element.removeEventListener('mousedown', onMouseDown)
      element.removeEventListener('mousemove', onMouseMove)
      element.removeEventListener('mouseup', onMouseUp)
      element.removeEventListener('mouseleave', onMouseUp)
      element.style.cursor = 'default'
    }, 30000)
  }

  const totalSlices = sliceNumbers.length

  return (
    <div
      className="relative rounded-xl sm:rounded-2xl overflow-hidden"
      style={{ aspectRatio: '4/3', backgroundColor: '#000' }}
    >
      {/* Cornerstone Canvas */}
      <div
        ref={viewerRef}
        className="w-full h-full"
        style={{ width: '100%', height: '100%' }}
      />

      {/* Индикатор среза */}
      <div className="absolute top-4 left-4 bg-primary-beige px-3 py-2 rounded-md shadow-sm">
        <span
          className="font-outfit font-normal text-[13px]"
          style={{ color: '#787771' }}
        >
          slice {currentSlice}/{totalSlices}
        </span>
      </div>

      {/* Инструменты */}
      <ViewerControls
        onZoomIn={handleZoomIn}
        onZoomOut={handleZoomOut}
        onPan={handlePan}
        onRotate={handleRotate}
      />
    </div>
  )
}

export default ViewerCanvas