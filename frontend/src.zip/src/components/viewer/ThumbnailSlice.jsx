import { useRef, useEffect, useState } from 'react'
import { getSlice } from '@/api'
import { cornerstone, cornerstoneWADOImageLoader } from '@/utils/cornerstoneSetup'

// Кеш для загруженных миниатюр
const thumbnailCache = new Map()

const ThumbnailSlice = ({ sliceNumber, scanId, token, isActive, onClick }) => {
  const canvasRef = useRef(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadThumbnail = async () => {
      if (!canvasRef.current) return

      const canvas = canvasRef.current
      const ctx = canvas.getContext('2d')

      try {
        // Проверяем кеш
        const cacheKey = `${scanId}-${sliceNumber}`
        let image

        if (thumbnailCache.has(cacheKey)) {
          image = thumbnailCache.get(cacheKey)
        } else {
          // Загружаем срез
          const result = await getSlice(scanId, sliceNumber, token)
          
          if (!result.success) {
            setIsLoading(false)
            return
          }

          // Конвертируем в imageId для cornerstone
          const blob = result.data
          const arrayBuffer = await blob.arrayBuffer()
          const byteArray = new Uint8Array(arrayBuffer)

          const imageId = cornerstoneWADOImageLoader.wadouri.fileManager.add(
            new File([byteArray], `thumb_${sliceNumber}.dcm`)
          )

          // Загружаем изображение через cornerstone
          image = await cornerstone.loadImage(imageId)
          
          // Кешируем
          thumbnailCache.set(cacheKey, image)
        }

        // Рендерим изображение
        renderThumbnail(canvas, ctx, image)
        setIsLoading(false)

      } catch (err) {
        console.error('Error loading thumbnail:', err)
        setIsLoading(false)
      }
    }

    loadThumbnail()
  }, [sliceNumber, scanId, token])

  const renderThumbnail = (canvas, ctx, image) => {
    if (!canvas || !ctx || !image) return

    // Устанавливаем размеры canvas
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width
    canvas.height = rect.height

    // Получаем данные пикселей
    const pixelData = image.getPixelData()
    const width = image.width
    const height = image.height

    // Вычисляем оконные значения для отображения
    const windowWidth = image.windowWidth || 400
    const windowCenter = image.windowCenter || 40
    const windowLow = windowCenter - windowWidth / 2
    const windowHigh = windowCenter + windowWidth / 2

    // Создаем ImageData для canvas
    const imageData = ctx.createImageData(width, height)
    const data = imageData.data

    // Конвертируем DICOM пиксели в RGB
    for (let i = 0; i < pixelData.length; i++) {
      let pixelValue = pixelData[i]
      
      // Применяем windowing
      if (pixelValue <= windowLow) {
        pixelValue = 0
      } else if (pixelValue >= windowHigh) {
        pixelValue = 255
      } else {
        pixelValue = ((pixelValue - windowLow) / windowWidth) * 255
      }

      const idx = i * 4
      data[idx] = pixelValue     // R
      data[idx + 1] = pixelValue // G
      data[idx + 2] = pixelValue // B
      data[idx + 3] = 255        // A
    }

    // Отрисовываем на временный canvas в оригинальном размере
    const tempCanvas = document.createElement('canvas')
    tempCanvas.width = width
    tempCanvas.height = height
    const tempCtx = tempCanvas.getContext('2d')
    tempCtx.putImageData(imageData, 0, 0)

    // Масштабируем и центрируем на основном canvas
    ctx.fillStyle = '#000'
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    const scale = Math.min(canvas.width / width, canvas.height / height)
    const scaledWidth = width * scale
    const scaledHeight = height * scale
    const x = (canvas.width - scaledWidth) / 2
    const y = (canvas.height - scaledHeight) / 2

    ctx.drawImage(tempCanvas, x, y, scaledWidth, scaledHeight)
  }

  return (
    <button
      onClick={onClick}
      className={`
        relative flex-1 aspect-square rounded-xl sm:rounded-2xl border-2 transition-all overflow-hidden
        ${isActive ? 'border-primary-navy' : 'border-transparent hover:border-gray-400'}
      `}
      style={{ backgroundColor: '#000' }}
    >
      <canvas ref={canvasRef} className="w-full h-full" />
      
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
        </div>
      )}
    </button>
  )
}

export default ThumbnailSlice
