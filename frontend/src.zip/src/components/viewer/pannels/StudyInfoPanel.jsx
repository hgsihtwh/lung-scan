import { useScanStore } from '@/store'

const StudyInfoPanel = () => {
  const { currentScanDetails, sliceNumbers } = useScanStore()
  
  const totalSlices = sliceNumbers.length

  return (
    <div className="border border-primary-dark rounded-xl sm:rounded-2xl p-5 lg:p-6">
      <h3 className="font-outfit font-medium text-lg lg:text-xl text-primary-dark mb-4">
        STUDY INFO
      </h3>
      
      <div className="space-y-2 lg:space-y-3">
        <div className="flex items-start gap-2 font-outfit text-sm lg:text-base">
          <span className="text-primary-dark opacity-60">Study ID:</span>
          <span className="text-primary-dark font-medium">
            {currentScanDetails?.patient_name || 'N/A'}
          </span>
        </div>
        
        <div className="flex items-start gap-2 font-outfit text-sm lg:text-base">
          <span className="text-primary-dark opacity-60">Slices:</span>
          <span className="text-primary-dark font-medium">
            {totalSlices}
          </span>
        </div>
        
        {currentScanDetails?.created_at && (
          <div className="flex items-start gap-2 font-outfit text-sm lg:text-base">
            <span className="text-primary-dark opacity-60">Date:</span>
            <span className="text-primary-dark font-medium">
              {new Date(currentScanDetails.created_at).toLocaleDateString('en-GB', {
                day: '2-digit',
                month: 'short',
                year: 'numeric'
              })}
            </span>
          </div>
        )}
        
        <div className="flex items-start gap-2 font-outfit text-sm lg:text-base">
          <span className="text-primary-dark opacity-60">Status:</span>
          <span className="text-primary-dark font-medium">
            {currentScanDetails?.status || 'Unknown'}
          </span>
        </div>
      </div>
    </div>
  )
}

export default StudyInfoPanel