import { create } from 'zustand'

export const useUIStore = create((set) => ({
  // State - Навигация
  currentStep: 'landing', // 'landing' | 'upload' | 'viewer'
  
  // State - Viewer UI
  thumbnailOffset: 0,
  
  // State - Панели
  comments: '',
  feedback: null, // null | 'accurate' | 'inaccurate'
  
  // State - Loading/Error для UI элементов
  isSavingFeedback: false,
  feedbackError: null,
  commentError: null,
  reportError: null,

  // Actions - Навигация
  setCurrentStep: (step) => 
    set({ currentStep: step }),

  goToLanding: () => 
    set({ currentStep: 'landing' }),

  goToUpload: () => 
    set({ currentStep: 'upload' }),

  goToViewer: () => 
    set({ currentStep: 'viewer' }),

  // Actions - Viewer UI
  setThumbnailOffset: (offset) => 
    set({ thumbnailOffset: offset }),

  // Actions - Комментарии
  setComments: (comments) => 
    set({ comments }),

  clearComments: () => 
    set({ comments: '' }),

  // Actions - Фидбек
  setFeedback: (feedback) => 
    set({ feedback }), // 'accurate' | 'inaccurate'

  clearFeedback: () => 
    set({ feedback: null }),

  setSavingFeedback: (saving) => 
    set({ isSavingFeedback: saving }),

  // Actions - Errors
  setFeedbackError: (error) => 
    set({ feedbackError: error }),

  setCommentError: (error) => 
    set({ commentError: error }),

  setReportError: (error) => 
    set({ reportError: error }),

  clearUIErrors: () => 
    set({ 
      feedbackError: null, 
      commentError: null, 
      reportError: null 
    }),

  // Actions - Сброс всего UI
  resetUI: () => 
    set({
      currentStep: 'landing',
      thumbnailOffset: 0,
      comments: '',
      feedback: null,
      isSavingFeedback: false,
      feedbackError: null,
      commentError: null,
      reportError: null
    }),
}))